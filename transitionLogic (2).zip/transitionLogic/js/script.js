     $(document).ready( function() {
     	setTimeout(function () {
     		$(".preloader").show()
    	$(".headingdivs").show()
}, 1000);
     /*	setTimeout(function () {
     		$(".wrapper").hide()
    $(".basicCarousel").show()
}, 16000);*/
$("#myCarousel").carousel("pause");

});
